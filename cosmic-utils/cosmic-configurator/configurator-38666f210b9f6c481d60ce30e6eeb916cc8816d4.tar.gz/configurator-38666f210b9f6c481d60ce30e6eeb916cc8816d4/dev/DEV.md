cosmic-panel problem

- n'utilise pas #[serde(default)]
- n'utilise pas les fichiers de configs system
