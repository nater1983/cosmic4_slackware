---
name: Bug Report
about: Report a correctness issue or violated expectation
labels: bug
---

#### Bug Description

#### Expected Result

#### Steps to Reproduce

#### Additional Information
