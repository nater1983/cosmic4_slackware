impl Serialize for Figment

impl Provider for JsonSchema
