#[derive(Debug, Default)]
pub struct Flags;

pub fn flags() -> Flags {
    Flags
}
